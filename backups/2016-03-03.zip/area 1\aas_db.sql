-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2016 at 08:10 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `aas_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_allowed`
--

CREATE TABLE IF NOT EXISTS `tbl_allowed` (
  `aid` int(6) NOT NULL AUTO_INCREMENT,
  `file_id` int(6) DEFAULT NULL,
  `user_id` int(6) DEFAULT NULL,
  `stat` int(2) DEFAULT '1',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_allowed`
--

INSERT INTO `tbl_allowed` (`aid`, `file_id`, `user_id`, `stat`) VALUES
(1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_areas`
--

CREATE TABLE IF NOT EXISTS `tbl_areas` (
  `area_id` int(3) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_areas`
--

INSERT INTO `tbl_areas` (`area_id`, `area_name`) VALUES
(1, 'Vision, Mission, Goals and Objectives'),
(2, 'The Faculty'),
(3, 'Curriculum and Instruction'),
(4, 'Support to Students'),
(5, 'Research'),
(6, 'Extension and Community Involvement'),
(7, 'Library'),
(8, 'Physical Plant and Facilities'),
(9, 'Laboratories'),
(10, 'Adminstration');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_backup`
--

CREATE TABLE IF NOT EXISTS `tbl_backup` (
  `bid` int(3) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `interv` int(4) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_backup`
--

INSERT INTO `tbl_backup` (`bid`, `date`, `interv`) VALUES
(1, '2015-12-17', 1),
(3, '2016-02-01', 1),
(4, '2016-02-02', 13);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_downloads`
--

CREATE TABLE IF NOT EXISTS `tbl_downloads` (
  `download_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` int(6) DEFAULT NULL,
  `user_id` int(6) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`download_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_downloads`
--

INSERT INTO `tbl_downloads` (`download_id`, `file_id`, `user_id`, `date`) VALUES
(1, 1, 1, '2015-12-16 15:58:32'),
(2, 2, 1, '2015-12-22 22:29:11'),
(3, 2, 1, '2015-12-22 22:46:13'),
(4, 2, 1, '2016-01-11 15:38:24'),
(5, 3, 1, '2016-01-11 15:39:09'),
(6, 3, 1, '2016-01-11 23:23:28'),
(7, 3, 1, '2016-01-12 00:55:53'),
(8, 0, 1, '2016-02-12 14:58:17'),
(9, 0, 1, '2016-02-12 15:06:17'),
(10, 0, 1, '2016-02-12 15:06:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_files`
--

CREATE TABLE IF NOT EXISTS `tbl_files` (
  `file_id` int(6) NOT NULL AUTO_INCREMENT,
  `filename` varchar(100) DEFAULT NULL,
  `author_id` int(6) DEFAULT NULL,
  `file_size` varchar(9) DEFAULT NULL,
  `file_type` varchar(10) DEFAULT NULL,
  `area` int(3) NOT NULL,
  `dir` int(6) DEFAULT NULL,
  `rest` int(3) DEFAULT '0',
  `upl_date` datetime DEFAULT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_files`
--

INSERT INTO `tbl_files` (`file_id`, `filename`, `author_id`, `file_size`, `file_type`, `area`, `dir`, `rest`, `upl_date`) VALUES
(1, 'Till death do us part.doc', 1, '350kb', 'mp4', 1, 0, NULL, NULL),
(2, 'Document2', 1, '258kb', 'pdf', 1, 0, NULL, NULL),
(3, 'Ang pagkabuhay ng dating patay', 1, '500kb', 'docx', 1, 0, 1, NULL),
(4, 'displays.png', 1, '68619 KB', 'png', 1, 0, 0, '2016-02-12 14:52:36'),
(5, 'displays.png', 1, '68619 KB', 'png', 1, 0, 0, '2016-02-12 10:47:25'),
(6, 'displays.png', 1, '68619 KB', 'png', 1, 0, 0, '2016-02-12 10:48:56'),
(7, 'displays.png', 1, '68619 KB', 'png', 1, 0, 0, '2016-02-12 10:50:13'),
(8, 'La_vie_en_rose.pdf', 1, '63245 KB', 'pdf', 1, 0, 0, '2016-02-12 10:51:40'),
(9, 'oh holy night.png', 1, '325074 KB', 'png', 1, 0, 0, '2016-02-12 10:56:57'),
(10, 'Funny-wallpaper-minion-july-2015.jpg', 1, '45667 KB', 'jpg', 1, 0, 0, '2016-02-12 14:57:06'),
(11, 'COUNTERFEIT MEDECINE PROLIFERATION IN CEBU CITY.docx', 1, '135521 KB', 'docx', 1, 0, 0, '2016-02-12 11:01:01'),
(12, 'Roberts-rules-SDSU.pdf', 1, '223420 KB', 'pdf', 1, 0, 0, '2016-02-12 11:01:40'),
(13, 'Jacquelyn L.docx', 1, '11399 KB', 'docx', 1, 0, 0, '2016-02-12 11:02:19'),
(14, 'displays.png', 1, '346003 KB', 'png', 1, 0, 0, '2016-02-12 14:34:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_folders`
--

CREATE TABLE IF NOT EXISTS `tbl_folders` (
  `fldr_id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `dir` varchar(3) DEFAULT NULL,
  `area` int(4) DEFAULT NULL,
  PRIMARY KEY (`fldr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `tbl_folders`
--

INSERT INTO `tbl_folders` (`fldr_id`, `name`, `date`, `dir`, `area`) VALUES
(1, 'Folder 1', '2016-01-13 10:22:54', '0', 1),
(9, 'Folder 2', '2016-01-18 01:24:31', '0', 1),
(10, 'Folder 3', '2016-01-18 01:25:58', '0', 1),
(11, 'Folder 4', '2016-01-18 01:27:26', '0', 1),
(12, 'Folder 1.1', '2016-01-18 01:27:37', '1', 1),
(13, 'Folder 1.1.1', '2016-01-18 01:27:48', '12', 1),
(14, 'Folder 1', '2016-01-21 01:30:35', 'und', 2),
(15, 'Folder 2', '2016-01-21 01:33:30', 'und', 2),
(16, 'Folder 1', '2016-01-21 01:42:34', '0', 3),
(17, 'Folder 1', '2016-01-21 01:42:48', '0', 7),
(18, '', '2016-01-21 20:48:29', '0', 2),
(19, 'Folder2', '2016-01-21 21:00:45', '17', 7);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notify`
--

CREATE TABLE IF NOT EXISTS `tbl_notify` (
  `nid` int(4) NOT NULL AUTO_INCREMENT,
  `file_id` int(6) DEFAULT NULL,
  `user_id` int(6) DEFAULT NULL,
  `status` int(3) DEFAULT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_notify`
--

INSERT INTO `tbl_notify` (`nid`, `file_id`, `user_id`, `status`) VALUES
(1, 2, 1, 1),
(2, 3, 1, 1),
(3, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_questions`
--

CREATE TABLE IF NOT EXISTS `tbl_questions` (
  `qid` int(3) NOT NULL AUTO_INCREMENT,
  `question` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `user_id` int(6) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `area` int(3) DEFAULT NULL,
  `user_type` int(3) DEFAULT NULL,
  `user_status` int(3) DEFAULT NULL,
  `sc_question` int(3) DEFAULT NULL,
  `sc_answer` int(3) DEFAULT NULL,
  `f_login` int(2) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `firstname`, `lastname`, `area`, `user_type`, `user_status`, `sc_question`, `sc_answer`, `f_login`, `username`, `password`) VALUES
(1, 'paul', 'george', 4, 1, 1, NULL, NULL, NULL, 'admin', 'password'),
(2, 'Jeffrey Noel', 'Quilaquil', 1, 2, 1, 0, 0, 1, 'jeffrey.quilaquil', 'something'),
(3, 'Ivy', 'Sabay', 3, 2, 1, 0, 2154, 1, 'ivy.sabay', '123456'),
(4, 'Herbert', 'Burdan', 8, 2, 1, 0, 25, 1, 'h.bert', 'herbert'),
(5, 'sds', 'dsds', 2, 1, 1, 0, 0, 1, 'sdsds', 'sdss'),
(6, 'Hulala', 'alaluH', 1, 1, 1, 0, 0, 1, '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
